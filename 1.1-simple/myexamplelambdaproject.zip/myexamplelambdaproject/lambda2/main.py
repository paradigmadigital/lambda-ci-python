def my_handler(event, context):
    message = 'Hello world lambda2!' 
    return { 
        'message' : message
    }   
